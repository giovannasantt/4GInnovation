using UnityEngine;

public enum PlayerStateType 
{
    Normal,
    Dead,
    Investigating,
    Brainstorm,
}
